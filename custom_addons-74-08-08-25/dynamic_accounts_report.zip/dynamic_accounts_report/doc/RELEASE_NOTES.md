## Module <dynamic_accounts_report>

#### 21.11.2024
#### Version 18.0.1.0.1
#### ADD
- Initial commit for Dynamic Accounts  Reports

#### 13.12.2024
#### Version 18.0.1.1.1
#### UPDT
- Fixed the errors in the filters.

#### 27.01.2025
#### Version 18.0.1.1.2
#### UPDT
- Fixed the errors in the filters.